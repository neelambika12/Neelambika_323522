package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import base_class.data;
import base_class.test_data;

public class excel_read {
	
	public static data read_sheet2(int j) {
			data dat=new data();
			try
			{
				File f=new File("D://poc1.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Keyword");
				XSSFRow rw=sh.getRow(j);
				dat.TC_ID=rw.getCell(0).getStringCellValue();
				dat.KeyWord=rw.getCell(2).getStringCellValue();
				dat.XPath=rw.getCell(3).getStringCellValue();
				dat.Test_Data=rw.getCell(4).getStringCellValue();
			}catch(Exception e){
				
			}
			return dat;
		}
		
	public static test_data read_sheet1(int j)  
		{
		test_data td=new test_data();
		try {
			
			File f=new File("poc1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("TC_Selection_Sheet");
			XSSFRow rw=sh.getRow(j);
			td.id=rw.getCell(0).getStringCellValue();
			td.flag=rw.getCell(1).getStringCellValue();
			td.steps=(int) rw.getCell(2).getNumericCellValue();
					
		}catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return td;
	}
	
	public static String read_ids(int i) throws IOException {
		String id;
		File f=new File("poc1.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Keyword");
		XSSFRow rw=sh.getRow(i);
		id=rw.getCell(0).getStringCellValue();

		return id;
		
	}
}
