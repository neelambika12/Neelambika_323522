package base_class;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class all_methods {
	
	static WebDriver dr;
	static WebDriverWait wait;
	static void waiting(String s) {
		wait=new WebDriverWait(dr,20);
		By locator = null;
		String attribute = null;
		wait.until(ExpectedConditions.attributeToBe(locator, attribute, s));
		
	}
	 public static void launchBrowser(String url)
	 {
		 System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		 dr=new ChromeDriver();
		 dr.get(url);
	 }
	
	 public static void r_sex(String Gender) {
		 List rb=dr.findElements(By.name("Gender"));
		 if(Gender=="Male")
			 ((WebElement) rb.get(0)).click();
		 else
			 ((WebElement) rb.get(1)).click();
	 }
	 
	 public static void enter_text(String xp,String value) {
		 dr.findElement(By.xpath(xp)).sendKeys(value);
	 }
	 
	 public static void clickButton(String xp) {
		 dr.findElement(By.xpath(xp)).click();
	 }
	 
	 public static String verify(String xpath, String expected) {
			String status;
			String actual = dr.findElement(By.xpath(xpath)).getText();
			if (actual.equals(expected)) {
				status = "PASS";
			} else
				status = "FAIL";
			return status;
			
		}
	 
	 
}
