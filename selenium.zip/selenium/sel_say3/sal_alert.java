package sal_day3;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class sal_alert
{
	public static void disply()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demo.guru99.com/test/delete_customer.php");
		dr.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/input")).sendKeys("cus123");
		
		dr.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[2]/input[1]")).click();
		
         Alert a=  dr.switchTo().alert();
         
         String Alret_msg =a.getText();
         System.out.println(Alret_msg);
         a.accept();
         
         Alert a1=dr.switchTo().alert();
         String Alret_msg1 =a.getText();
         System.out.println(Alret_msg1);
         a1.accept();
         
         dr.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/input")).sendKeys("123");
         dr.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[2]/input[1]")).click();
         Alert a2=  dr.switchTo().alert();
         
         String Alret_msg2 =a2.getText();
         System.out.println(Alret_msg2);
         a2.dismiss();
				
	}
	
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		

	}

}
