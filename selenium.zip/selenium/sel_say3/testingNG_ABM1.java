package sal_day3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import sal_day3.login;

public class testingNG_ABM1 {

	
@BeforeMethod
public void BM()
	{
		//File f=new File("C:\\Users\\neelambika.hs\\Documents\\3.xlsx");
		//FileInputStream fis;
		try {
			//fis = new FileInputStream(f);
		
		//XSSFWorkbook wb = new XSSFWorkbook(fis);
		//XSSFSheet sh=wb.getSheet("Sheet1");
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		} catch (Exception e) 
		{
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
	}
	
@AfterMethod
public void AM()
{
   
	
	
}




@Test
public void test1()
	{
	 
	    System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
	   dr.get("http://demowebshop.tricentis.com");
	   dr.findElement(By.xpath("// input[@id='Email']")).sendKeys("neel@gmail.com");
	   dr.findElement(By.xpath("// input[@id='Password']")).sendKeys("pass");
	   dr.findElement(By.xpath("// input[@value='Log in']")).click();
	
	 }
	
@Test	public void test2()
	{
	  System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
			WebDriver dr=new ChromeDriver();
		   dr.get("http://demowebshop.tricentis.com");
		   dr.findElement(By.xpath("// input[@id='Email']")).sendKeys("neelambikahs1998@gmail.com");
		   dr.findElement(By.xpath("// input[@id='Password']")).sendKeys("");
		   dr.findElement(By.xpath("// input[@value='Log in']")).click();
		
	}
	
@Test
public void test3()
{
	  
}

}
