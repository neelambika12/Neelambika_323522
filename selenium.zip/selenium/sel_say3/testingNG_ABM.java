package sal_day3;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class testingNG_ABM {
	
	WebDriver dr;
	
@BeforeClass	
public void get_data()
	{
		System.out.println("get  data");

	}
	
	@BeforeMethod
	public void BM()
	{
		System.out.println("Before Method");
	//	System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		//   dr=new ChromeDriver();
	}
	
	
@AfterMethod	
public void AM()
	{
		System.out.println("after method");

	}
	
  @Test(priority=1)
  public void A() 
  {
	  System.out.println("in A");
  }

  
  
  
@Test(priority=3)
public void a()
  {
	  System.out.println("in a");

  }


@Test(priority=2)
public void z()
{
	System.out.println("in z");

}
  
  
  
  
  
  
  
  
  
  
  
  
  
}
