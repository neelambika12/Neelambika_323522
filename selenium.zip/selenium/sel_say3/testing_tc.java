package sal_day3;

import org.testng.annotations.Test;

public class testing_tc extends sal_alert
{
  @Test
  public void f()
  {
	  disply();
	  System.out.println("in f ");
  }
}
