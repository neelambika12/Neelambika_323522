package sal_day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login {
	String eid,pwd,exp_res,act_res;

	public static String loginn(String a, String b)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
	  
	   dr.get("http://demowebshop.tricentis.com");
	   dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	   dr.findElement(By.xpath("// input[@id='Email']")).sendKeys(a);
	   dr.findElement(By.xpath("// input[@id='Password']")).sendKeys(b);
	   dr.findElement(By.xpath("// input[@value='Log in']")).click();
	    return null;
	   
	}
	
	
	
	
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		

	}

}
