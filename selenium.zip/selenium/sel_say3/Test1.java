package Testing_methods1;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Test1 {
  @Test
  public void testing_test()
  {
	  String er="NOIDA", ar="NOIDA";
	  System.out.println("in test");
	  Assert.assertEquals(ar,er);
	  
  }
 @Test
 public void testing_test1()
  {
	  String er="NOIDA", ar="NOID";
	  System.out.println("in test1");
	  Assert.assertEquals(ar,er);
	 }
}
