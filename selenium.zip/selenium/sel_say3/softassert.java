package sal_day3;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class softassert
{
  @Test
  public void test1() {
	  String er="NOIDA", ar="NOIDA";
	  System.out.println("in test1");
	  Assert.assertEquals(ar,er);
	  System.out.println("in test1-after assert");
	  
  }
  
@Test  public void test2()
  {
	  String er="NOIDA", ar="NOID";
	  System.out.println("in test2");
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(ar,er);
	  System.out.println("in test2-after assert");
	  sa.assertAll();
	  
  }
}
