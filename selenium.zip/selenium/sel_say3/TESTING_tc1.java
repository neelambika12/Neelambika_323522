package sal_day3;

import org.testng.annotations.Test;

public class TESTING_tc1 {
       sal_alert a=new sal_alert();
	
	@Test
  
 
  public void TC1()
  {
	  
	  
	  System.out.println("in tc1");
	  a.disply();
  }
  
@Test
 public void TC2()
  {
	  System.out.println("in tc2"); 
  }
   
  

  @Test
  public void tc3()
  {
	  System.out.println("in tc3");
  }
}

