package sal_day3;

import org.testng.Assert;
import org.testng.annotations.Test;

public class testingNG_test2  {
	
	

  @Test
  public void testing_test()
  {
	  String er="NOIDA", ar="NOIDA";
	  System.out.println("in test");
	  Assert.assertEquals(ar,er);
	  
  }
 @Test
 public void testing_test1()
  {
	  String er="NOIDA", ar="NOID";
	  System.out.println("in test1");
	  Assert.assertEquals(ar,er);
	 }
 
 
@Test
public void testing_test2()
 {
	
	//actal_res="";
	
	
 }
}
