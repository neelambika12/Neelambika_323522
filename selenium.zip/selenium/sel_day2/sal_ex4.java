package sal_day2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;


public class sal_ex4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
		
		File f=new File("C:\\Users\\neelambika.hs\\Documents\\aug5.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		for(int i=1;i<=3;i++) 
		{
			XSSFRow row=sh.getRow(i);
			XSSFCell cel1=row.getCell(0);
			XSSFCell cel2=row.getCell(1);
			XSSFCell cel3=row.getCell(2);
			dr.findElement(By.className("ico-login")).click();
			dr.findElement(By.id("Email")).sendKeys(cel1.getStringCellValue());
			dr.findElement(By.id("Password")).sendKeys(cel2.getStringCellValue());
			dr.findElement(By.xpath("//input[@value='Log in']")).click();
			FileOutputStream fos=new FileOutputStream(f);
			XSSFCell cell1=row.createCell(3);
			XSSFCell cell2=row.createCell(4);
		   String a=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
			System.out.println(a);
			
			                                
			
			if((cel3.getStringCellValue().equals(a)))
					{
				 cell1.setCellValue("pass");
				 cell1.setCellValue(a);
				}
				else {
					  cell1.setCellValue("fail");
					  cell1.setCellValue(a);
				}
				     wb.write(fos);
				     dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[1]/a/img")).click();
				     dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click(); 
				      
				}
		dr.close();
		}
			
			
			
			
		 catch(Exception e)
		{}

	}

}
