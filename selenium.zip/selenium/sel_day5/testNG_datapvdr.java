package aug_6;

import org.testng.Assert;
import org.testng.annotations.Test;

public class testNG_datapvdr {
  @Test
  public void login(String eid,String pwd,String er) 
  {
	  System.out.println(eid +" " + pwd + " " + er);
	  Assert.assertEquals("", expected);
  }
}
