package testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class selas3 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		String s=dr.getTitle();
		dr.findElement(By.className("ico-login")).click();
	    String cs="neelambikahs1998@gmail.com" ;
	     dr.findElement(By.xpath("// input[@id='Email']")).sendKeys("neelambikahs1998@gmail.com");
	    dr.findElement(By.xpath("// input[@id='Password']")).sendKeys("pass@123");
	    dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	  String m=  dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	    if(m.contentEquals(cs))
	    	System.out.println("content displayed");
	    dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	    
	}

}
