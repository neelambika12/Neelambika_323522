package testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class sel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.facebook.com");
		//dr.findElement(By.cssSelector("input[type='submit']")).click();
		dr.findElement(By.xpath("//input[@id='email']")).sendKeys("neelambikahs1998@gmail.com");
		//dr.findElement(By.xpath("//input[@id='pass']")).sendKeys("nnjahj");
	//	dr.findElement(By.xpath("//input[contains(text(),'Create a new')]"));
	//String s=dr.findElement(By.xpath("//*[contains(text(),'Create an')]")).getText();
	//System.out.println(s);
   //  dr.findElement(By.xpath("//input[@name='firstname']//following::input[1])")).sendKeys("neel");
		
	
//System.setProperty("webdriver.gecko.driver","geckodriver")
	

}
}