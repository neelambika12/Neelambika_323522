package testing;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class selas1 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		String exp="Demo Web Shop";
		String s="";
		s=dr.getTitle();
		if(exp.contentEquals(s)) 
		{
			
            System.out.println("it matches");
		}
		else
		{
			System.out.println("doesnot matches");
		}
		
	    dr.findElement(By.className("ico-register")).click();
	    //to create a radio button using following web elements//
	    List rb=dr.findElements(By.name("Gender"));
	   ((WebElement)rb.get(1)).click();
	   
	    dr.findElement(By.xpath("// input[@id='FirstName']")).sendKeys("neel");;
	    dr.findElement(By.xpath("// input[@id='LastName']")).sendKeys("Hs");;
	   dr.findElement(By.xpath("// input[@id='Email']")).sendKeys("neelambikahs1998@gmail.com");
	   dr.findElement(By.xpath("// input[@id='Password']")).sendKeys("pass@123");
       dr.findElement(By.xpath("// input[@id='ConfirmPassword']")).sendKeys("pass@123");
	   dr.findElement(By.xpath("// input[@id='register-button']")).click();
	   dr.close();
	
		

	}

}
