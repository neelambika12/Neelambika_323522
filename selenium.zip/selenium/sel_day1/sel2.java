package testing;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class sel2 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://demo.guru99.com/test/radio.html");
		
		
		//List rb=dr.findElements(By.name("sex"));      //rb is a list (java type)so we are type casting to web element
	//	((WebElement)rb.get(1)).click();
		
     // WebElement we=dr.findElement(By.id("u_0_7"));
    //  we.click();
		
		

		boolean cs=dr.findElement(By.id("vfb-6-0")).isSelected();
		boolean fs=true;
		if(cs==false)
		{
			if(fs==true)
			{
				dr.findElement(By.id("vfb-6-1")).click();
			}
		}
		else
		{
			if(fs==true)
			{
				dr.findElement(By.id("vfb-6-2")).click();
			}
		}
			
	}
}
