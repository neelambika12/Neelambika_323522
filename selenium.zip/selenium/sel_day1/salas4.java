package testing;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class salas4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			File f=new File("C:\\Users\\neelambika.hs\\Desktop\\saleniumExcel.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
			WebDriver dr=new ChromeDriver();
			dr.get("http://demowebshop.tricentis.com/");
			for(int i=1;i<=3;i++) {
				XSSFRow row=sh.getRow(i);
				XSSFCell cel1=row.getCell(0);
				XSSFCell cel2=row.getCell(1);
				XSSFCell cel3=row.getCell(2);
				dr.findElement(By.className("ico-login")).click();
				dr.findElement(By.id("Email")).sendKeys(cel1.getStringCellValue());
				dr.findElement(By.id("Password")).sendKeys(cel2.getStringCellValue());
				dr.findElement(By.xpath("//input[@value='Log in']")).click();
				FileOutputStream fos=new FileOutputStream(f);
				XSSFCell cell1=row.createCell(3);
				if(cel3.getStringCellValue().equals(dr.findElement(By.className("account")).getText())) {
				 cell1.setCellValue("pass");
				}
				else {
					  cell1.setCellValue("fail");}
				      wb.write(fos);
				      dr.findElement(By.xpath("//*[@class='ico-logout']")).click();   
				}
			dr.quit();	
			}
	      catch(Exception e) {}

	}

}
