package aug_5;

import org.openqa.selenium.WebDriver;

public class test11 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method 
		WebDriver dr=null;
		for(int i=1;i<=5;i++)
		{
			functions f=new functions();
			for(int j=1;j<5;j++)
			{
				
				if(j==1)
				{
					f.keywrd=f.read(i,j,"C:\\Users\\neelambika.hs\\Documents\\aug5.xlsx");
					System.out.println(f.keywrd);
				}
				else if(j==2)
				{
					f.xp=f.read(i,j,"C:\\Users\\neelambika.hs\\Documents\\aug5.xlsx");
					System.out.println(f.xp);
				}
				else if(j==3)
				{
					f.text_data=f.read(i,j,"C:\\Users\\neelambika.hs\\Documents\\aug5.xlsx");
					System.out.println(f.text_data);
				}
				else
				{	
					switch(f.keywrd)
					{
					case "launch browser":
						dr=f.browser(f.text_data);
						break;
					case "enter_text": 
						f.enter_text(f.xp, f.text_data, dr);
						break;
					case "click":
						f.click(f.xp, dr);
						break;
					case "verify":
						boolean data=f.verify(f.xp, f.text_data, dr);
						f.write(i, j, "C:\\Users\\neelambika.hs\\Documents\\aug55.xlsx", data);
						
						break;
					}
				}
			}
		}
		

}
}