package aug_5;

public class useraction {
	
	
	String keyword;
	String xpath;
	String text_data;
	public useraction(String keyword,String xpath,String text_data)
	{
		
	}

}
