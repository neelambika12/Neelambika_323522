package base_class;

public class test_data {
	public int steps;
	public String id;
	public String flag;


}
