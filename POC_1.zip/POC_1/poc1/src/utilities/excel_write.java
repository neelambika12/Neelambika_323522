package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_write {
	 public static void write_sheet1(int x,String a)
	 {
		 try {
			 File f=new File("poc1.xlsx");
			 FileInputStream fis=new FileInputStream(f);
			 XSSFWorkbook wb=new XSSFWorkbook(fis);
			 XSSFSheet sh=wb.getSheet("TC_Selection_Sheet");
			 XSSFRow row=sh.getRow(x);
			 XSSFCell cell4=row.getCell(3);
			 cell4.setCellValue(a);
			 FileOutputStream fos=new FileOutputStream(f);
			 wb.write(fos);
		 }catch(Exception e){}
	 }
	 public static void write_sheet2(int x,String a) {
		 try {
			 File f=new File("poc1.xlsx");
			 FileInputStream fis=new FileInputStream(f);
			 XSSFWorkbook wb=new XSSFWorkbook(fis);
			 XSSFSheet sh=wb.getSheet("Keyword");
			 XSSFRow row=sh.getRow(x);
			 XSSFCell cell6=row.getCell(5);
			 cell6.setCellValue(a);
			 FileOutputStream fos=new FileOutputStream(f);
			 wb.write(fos);
		 }catch(Exception e) {}
	 }
}
