package Base_class;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class login_page
{
     WebDriver dr;
	
	

	@FindBy(xpath="//*[@id=\"Email\"]")
	WebElement eid;
	@FindBy(xpath="//*[@id=\"Password\"]")
	WebElement pd;
	@FindBy(xpath="/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")
	WebElement cl_lg;
	
	
   public login_page(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
   public String get_login_page_title()
   {
	   return dr.getTitle();
   }
   
  	
 
   public void login_details(String email,String pwd)
   {
	  
	   eid.sendKeys(email);
	   pd.sendKeys(pwd);
	  cl_lg.click();
 }
   
  
   
  	
	
}
