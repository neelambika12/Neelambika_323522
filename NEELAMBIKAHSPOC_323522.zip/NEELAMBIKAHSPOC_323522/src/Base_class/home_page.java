package Base_class;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class home_page
{
static WebDriver dr;


@FindBy(className="ico-register")
WebElement register;

@FindBy(className="ico-login")
WebElement login;
	public home_page(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
  public String get_home_page_title()
	{
		return dr.getTitle();
		
	}
	public String get_register_page_title()
	{
		return register.getText();
	}
	
	public String get_login_title()
	{
		
		return login.getText();
		
	}
	public void click_login()
	{
		login.click();
	}
	
}
