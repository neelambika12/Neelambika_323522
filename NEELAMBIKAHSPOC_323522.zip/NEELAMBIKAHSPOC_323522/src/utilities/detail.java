package utilities;

public class detail
{
public String email;
public String pwd;
public String expec;
}
