package testing_tests;





import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import Base_class.home_page;
import Base_class.login_page;

public class TestNGclass1
{

	WebDriver dr;
	home_page hp;
	Logger log;
	login_page lp;
  @BeforeClass
  public void browser() 
  {
	  System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
	
  }
  
  public void logg(String er, String ar,String status)
  {
	  log=Logger.getLogger("devpinoyLogger");
	  log.info("\nExpected value:"+er+"\n Actual value:"+ar+"\n Test result:"+status+"\n");
			  
  }
  
  @Test(priority=1)
  public void test1()
  {
	  hp=new home_page(dr);
	   String  status="failed";
	String ar=  hp.get_home_page_title();
	String er="Demo Web Shop";
	Assert.assertEquals(ar, er);
	status="passed";
	logg(er,ar,status);
	
	
  }
  
  
  @Test(priority=2)
  public void test2()
  {
	 hp=new home_page(dr);
	 String status="failed";
	 String ar=hp.get_register_page_title();
	 
	 String er="Register";
	 Assert.assertEquals(ar, er);
	 status="passed";
	 logg(er,ar,status);
	  
	  
  }
 @Test(priority=3)
 public void test3()
  {
	 hp=new home_page(dr);
	 String status="failed";
	 String ar=hp.get_login_title();
	 String er="Log in";
	 Assert.assertEquals(ar, er);
	 status="passed";
	 logg(er,ar,status);
}
@Test(priority=4)
public void test4()
 {
	 hp=new home_page(dr);
	 hp.click_login();
 }
//@Test(priority=5)
//public void test5() 
//{
//	String status="failed";
//	 lp=new login_page(dr);
//	 String er="Demo Web Shop. Login";
//	 String ar=lp.get_login_page_title();
//    Assert.assertEquals(ar, er);
//	 status="passed";
//	logg(er,ar,status);
//}
//  
}
