package testing_tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Base_class.account_page;
import Base_class.home_page;
import Base_class.login_page;
import utilities.read_write;

public class TestNGclass2 extends TestNGclass1
{
	
	login_page lp;
	account_page ap;
	WebDriverWait wt;
	
	public void waitexp(String path)
	{
		wt=new WebDriverWait(dr,10);
		wt.until(ExpectedConditions.presenceOfElementLocated(By.xpath(path)));
	}
	

	
	@Test(priority=5)
	  public void test5() 
	  {
		String status="failed";
		 lp=new login_page(dr);
		 String er="Demo Web Shop. Login";
		 String ar=lp.get_login_page_title();
          Assert.assertEquals(ar, er);
		 status="passed";
		logg(er,ar,status);
	  }
	
	 
	 @Test(dataProvider="data",priority=6)
	 public void test6(String email,String pwd,String expec) 
	  {
		String status="failed";
		 lp=new login_page(dr);
	     lp.login_details(email, pwd);
	     ap=new account_page(dr);
	     waitexp("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a");
         String ar=expec;
         String er=ap.verifyemail();
         Assert.assertEquals(ar, er);
	     status="passed";
		logg(er,ar,status);
		ap.signout();
		hp.click_login();
         
	  }

	
	
	@DataProvider(name="data")
	public String[][] data()
	{
	//String[][] str= {{"neelambikahs1998@gmail.com","pass@123"},{"shilpymishra788@gmail.com","hannah"}};

	  read_write rw=new read_write();
      String[][] str= rw.readExcel();
	   return str;
     
	}
}
