//Name:NEELAMBIKA HS
//Java Program to Check Whether an Alphabet is Vowel or Consonant
//=================================================================================


package pri;

import java.util.Scanner;

public class vowels {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input=new Scanner(System.in);
		System.out.println("enter  character");
		char c = input.next().charAt(0);
		System.out.println(c);
		if(c=='a'|| c=='e'|| c=='i'|| c=='o'|| c=='u')
		    System.out.println("is a vowel");
	    else
		    System.out.println("is a consonent");		
		

	}

}
