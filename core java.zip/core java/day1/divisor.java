//Name:Neelambika HS
//write a program to check arithmetic operators?
//=====================================================================================

package day1;

public class divisor {

	public static void main(String[] args){
		int a = 32,x,y;
		float m =42.0f,n,p;
		
		x = a/10;
		System.out.println(x);
		y = a%10;
		System.out.println(y);
		
		n=m/10;
		System.out.println(n);
		p = m%10;
		System.out.println(p);
	}
}
