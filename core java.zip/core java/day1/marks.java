//Name:NEELAMBIKA HS
//WAP to check the marks of the students and print the pass class:
//i) Less than 35 : fail
//ii) More than 35 & less than 50 : Pass
//iii) More than 50 & less than 60 : 2nd Class
//iv) More than 60 & less than 70 : 1st Class
//v) More than 70 : Distinction
========================================================================================

package oops;

public class marks {
	public static void main(String[] args){
		float marks = 70.0f;
		
		if(marks>=75.0f){
			System.out.println("FCD");
		}
		else if(marks >= 60.0f){
			System.out.println("FC");
		}
		else if(marks >= 50.0f ){
			System.out.println("SC");
		}
		else if(marks >= 35.0f ){
			System.out.println("PC");
		}
		else{
			System.out.println("F");
		}
	}

}
