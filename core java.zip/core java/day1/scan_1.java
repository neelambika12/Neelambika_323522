//Name:NEELAMBIKA HS
//q)Write a program to accept as input, marks in 4 subjects of each of the 3 students. 
  // Calculate the average of each student. Print the name & total marks of the student who scored highest average.
//=========================================================================================================================


package day1;

import java.util.Scanner;

public class scan_1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input =new Scanner(System.in);
		int a1m,a2m,a3m,a4m ,b1m,b2m,b3m,b4m ,c1m,c2m,c3m,c4m;
		int summ1 = 0,summ2 = 0,summ3 =0;
		double avg1,avg2,avg3;
		String name1,name2,name3;
		
		name1 = input.next();
		System.out.println("name "+name1);
			a1m = input.nextInt();
			a2m = input.nextInt();
			a3m = input.nextInt();
			a4m = input.nextInt();
			summ1 = a1m+a2m+a3m+a4m;
			System.out.println("sum "+summ1);
			avg1 =summ1/4;
			System.out.println("avg "+ avg1);
			
			name2 = input.next();
		System.out.println("student "+name2);
			b1m = input.nextInt();
			b2m = input.nextInt();
			b3m = input.nextInt();
			b4m = input.nextInt();
			summ2 = b1m+b2m+b3m+b4m;
			System.out.println("sum "+summ2);
			avg2 =summ2/4;
			System.out.println("avg "+avg2);
			
			name3 = input.next();
		System.out.println("student "+name3);	
			c1m = input.nextInt();
			c2m = input.nextInt();
			c3m = input.nextInt();
			c4m = input.nextInt();
			summ3 = c1m+c2m+c3m+c4m;
			System.out.println("sum "+summ3);
			avg3 =summ3/4;
			System.out.println("avg "+avg3);
			
			if(avg1>avg2){
				if(avg1>avg3){
					System.out.println("marks "+summ1+ "name" + name1);
					}
				}
			else if(avg2>avg3){
				System.out.println("marks " + summ2 +"name" +name2);
			}
			else{
				System.out.println("marks" + summ3 + "name" + name3);
			}
			}
}


