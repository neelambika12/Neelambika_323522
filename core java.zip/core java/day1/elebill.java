//Name:Neelambika HS

//question)  W.A.P. to evaluate electricity bill on the following basis.
//� Upto 100 units Rs. 1.50
//� For the next 100 units Rs. 2.00
//� For next 50 units Rs. 2.50
//� Beyond 250 units Rs. 4.00

//=====================================================================================



package pri;

public class elebill {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     float b=135.0f;
     double sum=0.0f;
     if(b<=100)
     {
    	sum=b*1.5 ;
     }
     else if(b>100 && b<=200)
     {
    	 sum=150+(b-100)*2;
     }
     else if(b>200&& b<=250)
     {
    	sum=150+200*2.0+(b-200)*2.5; 
     }
     else if(b>250&& b<300)
     {
    	 sum=150+200*2.0+(b-250)*4.0;
     }
    	 System.out.println(sum);
	}

}
