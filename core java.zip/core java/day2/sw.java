package pri;

public class sw {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=13;
		switch(n)
		{
		case 12:
			    System.out.println("12");
		        
		case 13: 
			    System.out.println("13");
                 
		case 7: 
			    System.out.println("7");
                break;
		case 6:
			    System.out.println("6");
			    break;
			    
		default:
			   System.out.println("default");
			   break;
          

		}


	}

}
