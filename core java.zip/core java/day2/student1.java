package pri;
public class student1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student s=new student();
		student s1=new student();
		s.name="girish";
		s1.name="suresh";
		s.mark1=45;
		s.mark2=87;
		s1.mark1=56;
		s1.mark2=45;
		s.average();
		s1.average();
		float a1=s.avg;
		float a2=s.avg;
		if(a1>a2)
		{
			s.display_details();
		}
		else
		{
			s1.display_details();
		}
			
		
		
		

	}

}
