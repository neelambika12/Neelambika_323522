package pri;

public class student {
	    String name;
	    int mark1;
	    int mark2;
	    float avg;
	    
	    public void average()
	    {
	    	avg=(mark1+mark2)/2;
	    }
	    public void display_details()
	    {
	    	System.out.println("name= " + name + " mark1= " +  mark1 + " mark2= "+  mark2 +" avg= "+ avg);
	    }

	

}
