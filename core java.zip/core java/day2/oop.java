package pri;

public class oop {
	class mobile
	{
		String color;
		float len;
		String brand;
	}
	public void call()
	{
		System.out.println("mobile is calling");
	}
	public void msg()
	{
		System.out.println("mobile is messaging");
	}
	public void display_details()
	{
		System.out.println("color= "+ color + "len="+ len + "brand="+ brand);
	}


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		oop o= new oop();
		o.color="balck";
		o.brand
		o.call();
		o.msg();
		o.display_details();

	}

}
