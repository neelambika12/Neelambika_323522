package prime;

public class mobile_test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		mobile smg = new mobile();
		smg.color = "blue";
		smg.len = 4.0f;
		smg.breadth = 5.0f;
		smg.brand = "samsung";
		smg.call();
		smg.msg();
		smg.displayitems();
	}

}
