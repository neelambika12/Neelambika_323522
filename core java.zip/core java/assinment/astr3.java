package assingnment;

public class astr3 {
	    public static void main(String[] args) {
	        String str = "i love java program.";
	        char ch = 'a';
	        int frequency = 0;
	        for(int i = 0; i < str.length(); i++) {
	            if(ch == str.charAt(i)) {
	                ++frequency;
	            }
	        }
	        System.out.println("Frequency of " + ch + " = " + frequency);
	    }
	}


