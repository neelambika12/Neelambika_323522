package assingnment;

public class q14 {
	public static void main(String[] args){
		int sum = 0;
		/*for(int i =0;i<=200;i++){
			if((i%7 == 0) && (i%11 == 0)){
				System.out.println(i);
				sum =sum+i;
			}
			}
		*/
		for(int i=7;i<=200;i=i+7){
			if(i%11 == 0){
				sum =sum+i;
			}
		}
		System.out.println("sum :" +sum);
	}

}
