package assingnment;

public class fd_account extends account {
	//private int rate;
	int mat_amt;
	public void fd_rate(int rate,int time)
	{
		this.rate=rate;
		this.time=time;
	}
	public int calc_mat_amt()
	{
		return mat_amt=accountbal+calculate_rate();
	}

}
