package assingnment;

public class test_account {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
          sb_account ram=new sb_account();
          sb_account sham=new sb_account();
          fd_account prashant=new fd_account();
          ram.deposit(25000);
          
          sham.deposit(35000);
          prashant.deposit(20000);
          ram.sb_rate(4,1);
          sham.sb_rate(4,1);
          prashant.fd_rate(6,1);
          int x=ram.calculate_rate();
          System.out.println(x);
          
          int y=sham.calculate_rate();
          System.out.println(y);
          int z=prashant.calculate_rate();
          System.out.println(z);
          //ram.display();
          int m=prashant.calc_mat_amt();
          System.out.println(m);
          
        
          
          
	}

}
