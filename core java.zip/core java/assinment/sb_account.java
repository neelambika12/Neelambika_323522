package assingnment;

public class sb_account extends account 
{
	
	public void sb_rate(int rate,int time)
	{
		this.rate=rate;
		this.time=time;
	}
    
}
