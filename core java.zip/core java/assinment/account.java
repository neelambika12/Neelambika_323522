package assingnment;

public class account {
	int amt=0,time;
	int accountbal;
	int rate;
	public int calculate_rate()
	{
		amt=(accountbal*rate*time)/100;
		return amt+accountbal;
	}
	
	public void display()
	{
	System.out.println("accountbal:" + accountbal);
	}
	public void deposit(int amt)
	{
		accountbal+=amt;
	}
	public void withdraw(int amt)
	{
		accountbal-=amt;
	}


}
