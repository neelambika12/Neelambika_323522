package oops;

public class emp1 {
	static int b=0;
	int c=0;
	
	public emp1()
	{
		c++;
		b++;
	}

}
