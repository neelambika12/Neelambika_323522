package oops;

public abstract class testemp1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		emp1 e1=new emp1();
		System.out.println(e1.b+ "   "+e1.c);
		emp1 e2=new emp1();
		System.out.println(e2.b+"   "+e2.c);

	}

}
