package oops;

 class consultant extends abst
{
	int totalhrswork;
	public int calc_monthly_salary()
	{
		int sal;
		sal=totalhrswork*rateperunit;
		return sal;
		
	}
	
	consultant(int totalhrswork,int eid, String ename, int rateperunit )
	{
		super(eid,ename,rateperunit);//super keyword constructor of parent cls
		this.totalhrswork=totalhrswork;
	}

	
}
