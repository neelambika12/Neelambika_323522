package oops;

public class emp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
consultant c=new consultant(123,1234,"xyz",301);
int x=c.calc_monthly_salary();
System.out.println("salary "  +  x);

	}

}
