package oops;

class fte extends abst{
	int totaldaysworked;
public int calc_monthly_salary()
	{
		int sal;
		sal=totaldaysworked*rateperunit;
		return sal;
	}
public	fte(int totaldaysworked,int eid, String ename, int rateperunit )
	{
		super(eid,ename,rateperunit);
		this.totaldaysworked=totaldaysworked;
	}

}
