package pri;

public class pattern {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int j=1;j<=5;j++)
		{
			for(int i=1;i<=j;i++)
			{
				System.out.print(j);
			}
			System.out.println();
			//k++;
		}
		

	}

}
