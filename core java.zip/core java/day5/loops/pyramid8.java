package pri;

public class pyramid8 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=4;
		for(int i=1;i<=5;i++)
		{
			for(int j=5;j>i;j--)
			{
				System.out.print(" ");
			}
			for(int k=1;k<=i;k++)
			{
				System.out.print(i);
				System.out.print(" ");
			}
			System.out.println();
		}
	  //  int	m=4;
		
		for(int l=1;l<=4;l++)
		{
			for(int x=1;x<=l;x++)
			{
				System.out.print(" ");
			}
			for(int n=4;n>=l;n--)
			{
				System.out.print(c);
				System.out.print(" ");
			}
			c--;
			System.out.println();
		}
		

	}

}
