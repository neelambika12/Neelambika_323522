package oops;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javafx.scene.control.Cell;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_io_1 {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		File f=new File("C:\\Users\\neelambika.hs\\Desktop\\Newfolder\\Book1.xlsx");
		FileInputStream fis;
		try {
			fis = new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow row1=sh.createRow(2);
			XSSFCell cell1=row1.createCell(0);
			cell1.setCellValue("global");
			
			
			//XSSFRow row= sh.getRow(0);
		//	XSSFCell cell=row.getCell(0);
			
			//String s=cell.getStringCellValue();
			 //System.out.println("data:"+   s);
			 FileOutputStream fos= new FileOutputStream(f);
			 //cell.setCellValue("noida");
			 wb.write(fos);
			 
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 
	}

}
