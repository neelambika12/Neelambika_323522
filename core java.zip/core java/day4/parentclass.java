package pri;

public class parentclass {

	/**
	 * @param args
	 */
	
		// TODO Auto-generated method stub
		private static int a=10; 
		int b=20;
		protected int c=30;
		public int d=40;
		public static void display()
		{
			System.out.println(a);
		}
		

	

}
