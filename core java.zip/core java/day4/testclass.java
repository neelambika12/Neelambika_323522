package oops;

public class testclass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		childclass2 cc=new childclass2();
		cc.details();
		
		


}
}