package oops;

public class tryy {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=0,c;
		int b1[]={23,45,22,21,44};
		System.out.println(a);
	//	c=a/b;
      //  System.out.println(c);
		try
		{
			
			System.out.println(b1[2]);
			
			System.out.println(b1[5]);
			
			System.out.println("hi");
			
		}
		catch(ArithmeticException e)
		{
			System.out.println("inside block - ArithmeticException");
		}
		catch(ArrayIndexOutOfBoundsException ae)
		{
			System.out.println("outside block-ArrayIndexOutOfBoundsException");
		}
		System.out.println("out of catch block");

	}

}
