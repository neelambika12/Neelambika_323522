package oops;

import pri.parentclass;

public class childclass2 extends parentclass{

	/**
	 * @param args
	 */
	public void details()
	{
		//System.out.println(a);
		//System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//parentclass pc=new parentclass();


	}

}
