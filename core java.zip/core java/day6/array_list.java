package arrlist;

import java.util.ArrayList;

public class array_list {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> a1=new ArrayList<String>();
		a1.add("sanjay");
		a1.add("sumit");
		System.out.println(a1);
		for(String s :a1)
		{
			System.out.println(s);
		}
		String s1=a1.get(0);
		System.out.println(s1);
		

	}

}
