package arrlist;

public class student {
	public int id;
	public String name;
	public int phy;
	public int chem;
	public float avg;
	
	
	public void average()
	{
		avg=(phy+chem)/2f;
	}
	
	public student(int id,String name,int phy,int chem)
	{
	this.id=id;
	this.name=name;
	this.phy=phy;
	this.chem=chem;

}
}