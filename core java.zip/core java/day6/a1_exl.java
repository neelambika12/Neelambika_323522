package arrlist;

import java.util.ArrayList;

public class a1_exl {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<student> semester =new ArrayList<student>();
		
		student ramesh =new student(101,"ramesh",70,90);
		student rakesh =new student(101,"rakesh",80,90);
		student seema =new student(101,"seema",50,94);
		student pinky =new student(101,"pinky",20,90);
		
		a1_exl ex=new a1_exl();

		semester.add(ramesh);
		semester.add(rakesh);
		semester.add(seema);
		ex.display(semester);
		//System.out.println("===============================");
		//semester.add(1, pinky);
		//ex.display(semester);
	}
		
		public void display(student s)
		{
			System.out.println("ID: "+ s.id +"\n"+ "name: "+s.name+"\n"+"physics: "+ s.phy +"\n"+"chemistry :"+ s.chem+ "\n"+ "average :"+ s.avg);
		}
		
		


	

	public void display(ArrayList<student> std)
	{
		// TODO Auto-generated method stub
		for(student s:std)
		{
			System.out.println("*******************");
			s.average();
			System.out.println("ID: "+ s.id +"\n"+ "name: "+s.name+"\n"+"physics: "+ s.phy +"\n"+"chemistry :"+ s.chem+ "\n"+ "average :"+ s.avg);
		}
	}

}
