package pri;

public class elephant extends animal {
	String gender;
	int trunk_size;
	int age;
	
	

}
