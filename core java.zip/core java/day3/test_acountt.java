package pri;

public class test_acountt {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		acountt acc1=new acountt();
		acc1.setAcc_bal(1000);
		acc1.setAcc_no(2436);
		System.out.println("account bal is" + acc1.getAcc_bal());
		
		

	}

}
