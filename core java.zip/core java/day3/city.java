package oops;

public class city extends bank{

	public float get_roi()
	{
		return 6.4f;
	}
}
