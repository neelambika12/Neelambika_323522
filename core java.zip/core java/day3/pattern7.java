package pri;

public class pattern7
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		for(int i=5;i>=1;i--)
		{
			for(int z=5;z>i;z--)
				System.out.print(" ");
			for(int j=5;j>5-i;j--)
			{
				System.out.print(i);
				
			}
			System.out.println();
		}

	}

}
