package pri;

public class poly {
	int add(int x,int y)
	{
		int z;
		z=x+y;
		return z;
	}
	int add(int x,int y,int z)
	{
		int m=x+y+z;
		return m;
	}
	
	

	/**
	 * @param args
	 */
	
}
