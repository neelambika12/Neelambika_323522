package pri;

public class animal {
	String animal_color;
	int animal_count;
	String eating_type;
	String habitat;
	
	public string get_animal_det()
	{
		
	}
	
	

}
