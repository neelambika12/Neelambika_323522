package oops;

public class bank {
	public float get_roi()
	{
		return 0f;
	}

}
