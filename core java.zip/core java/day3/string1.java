package pri;

public class string1{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="I am learning core java",s1="hello", s2="hello",s3;
		int p=0,i=0,c=0;
		//t=s.length();
	//ystem.out.println(i);
		//stem.out.println(s1.compareTo(s2));
		//stem.out.println(s.substring(0,4));
		while(p!=-1)
		{
			p=s.indexOf('a',i);
			i=p+1;
			c++;
			
		}
		System.out.println(c);
		
		
		

	}

}
