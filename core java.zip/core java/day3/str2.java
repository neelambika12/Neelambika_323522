package pri;

public class str2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	String s = "I am learing java ";
	
	int i=s.length();
	
	for(i=0;i<s.length();i++)
	{
		int m=s.indexOf(' ',i);
		String s2=s.substring(i,m);
		i=m;
		System.out.println(s2);
		
		
	}
		
		

	
	}

}
