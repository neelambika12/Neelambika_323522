package pri;

public class assign13 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int fact=1,i;
		int n=5;
		for(i=1;i<=n;i++)
		{
			fact=fact*i;
		}
		System.out.println("facttorial of 5 is  "  +   fact);

	}

}
