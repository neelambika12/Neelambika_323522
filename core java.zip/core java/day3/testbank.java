package oops;

public class testbank {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		bank b;
		b=new icici();
		System.out.println(b.get_roi());
		b=new city();
		System.out.println(b.get_roi());
		

	}

}
