package pri;

public class polly {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		poly p=new poly();
		
		int j=p.add(2,4);
		int h=p.add(3,4,4);
		System.out.println(j);
		System.out.println(h);

	}

}
